import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) throws Exception {
        Connection conn = null;

        LocalDateTime dataAtual = LocalDateTime.now();
        Pessoa pessoa = new Pessoa("Belicio Cardoso", dataAtual);
        Pessoa pessoa2 = new Pessoa("Antonio", dataAtual);

        //System.out.println(dataAtual);

        try {
            conn = ConnectJDBC.getConnection();
            System.out.println("Conectado com sucesso!!!");
            Statement stm = conn.createStatement();
            stm.execute(pessoa.sqlCreateTable);

            stm.execute(pessoa.sqlInsert(pessoa2.getNome(),pessoa2.getData()));
            stm.execute(pessoa.sqlInsert(pessoa.getNome(), pessoa.getData()));
            stm.execute(pessoa.sqlInsert(pessoa2.getNome(), dataAtual));
            stm.execute(pessoa.sqlInsert("Maria José", dataAtual));

            ResultSet rd = stm.executeQuery("SELECT * FROM pessoa;");
            //System.out.println(pessoa.getNome());
            while (rd.next()){
                System.out.println("---------------------------------");
                System.out.println(" Id: " +rd.getInt(1)+" | Nome: "+rd.getString(2) +" | Data de Registro: "+ rd.getString(3));
            }
        } catch (Exception e){
            System.out.println("Erro na conexão");
            e.printStackTrace();
        }finally {
            if(conn == null){
                return;
            }
            System.out.println("Conection fechado!!!");
            conn.close();
        }
    }
}
