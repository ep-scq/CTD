import java.time.LocalDateTime;
public class Pessoa {
    private int id;
    private String nome;
    private LocalDateTime dateAtual;
    public Pessoa( String nome, LocalDateTime data) {
        this.nome = nome;
        this.dateAtual = data;
    }
    public String dropTable = "DROP TABLE IF EXISTS pessoa;";
    public String sqlCreateTable =  "CREATE TABLE IF NOT EXISTS pessoa "+
            "(Id Int AUTO_INCREMENT PRIMARY KEY, "+
            "name VARCHAR(50) NOT NULL, " +
            "datacadastro DATETIME);";

    public String sqlInsert (String name, LocalDateTime dateAtual){
        return "INSERT INTO pessoa (name, datacadastro) VALUES ('" + name + "','" + dateAtual + "');";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDateTime getData() {
        return dateAtual;
    }

    public void setData(LocalDateTime data) {
        this.dateAtual = data;
    }

    public LocalDateTime getDateAtual() {
        return dateAtual;
    }
}
