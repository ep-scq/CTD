import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectJDBC {
     public static Connection getConnection() throws Exception{
         final String DB_URL = "jdbc:mysql://10.0.1.10/dados?useTimezone=true&serverTimezone=America/Sao_Paulo";
         final String USERNAME = "db_user2";
         final String PASSWORD = "123456";

         //final String CLASSNAME = "org.h2.Driver";
         // Class.forName(CLASSNAME);

        return DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
        //jdbc:mysql://localhost/loja_virtual?useTimezone=true&serverTimezone=UTC
        //jdbc:mysql://localhost:3306
    }

}





