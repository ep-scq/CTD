package com.dh.clinica.dao.impl;

import com.dh.clinica.dao.ConfiguracaoJDBC;
import com.dh.clinica.dao.IDao;
import com.dh.clinica.model.Paciente;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PacienteDaoH2 implements IDao<Paciente> {

    private ConfiguracaoJDBC configuracaoJDBC;
    final static Logger logger = Logger.getLogger(PacienteDaoH2.class);

    @Override
    public Paciente cadastrar(Paciente paciente) throws SQLException {
        logger.info("Cadastrando Paciente: " + paciente.getNome());
        configuracaoJDBC = new ConfiguracaoJDBC("org.h2.Driver","jdbc:h2:~/consultorio;INIT=RUNSCRIPT FROM 'create.sql'","sa","");
        Connection connection = configuracaoJDBC.getConnection();

        String query = String.format("INSERT INTO consultorio (nome, sobrenome, rg, endereco)" +
                " VALUES ('%s','%s','%s','%s');",paciente.getNome(),paciente.getSobrenome(),paciente.getRg(),paciente.getEndereco());

        try {
            logger.info("Paciente cadastrado com sucesso!");
            Statement statement = connection.createStatement();
            statement.execute(query,Statement.RETURN_GENERATED_KEYS);

            ResultSet resultSet = statement.getGeneratedKeys();

            if(resultSet.next()){
                paciente.setId(resultSet.getInt(1));
            }

        }catch (Exception e){
            logger.error("Ocorreu um erro na aplicação.");
            e.printStackTrace();

        }finally {
            connection.close();
        }

        return paciente;
    }
}
