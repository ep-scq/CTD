package com.dh.clinica.service;

import com.dh.clinica.dao.impl.PacienteDaoH2;
import com.dh.clinica.model.Paciente;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;

class PacienteServiceTest {

    PacienteService pacienteService;

    @BeforeEach
    void doBefore(){
        pacienteService = new PacienteService(new PacienteDaoH2());
    }

    @Test
    public void cadastrarPaciente() throws SQLException {
        Paciente paciente = new Paciente("Tiburcio","Da Onça","123456789","Rua dos Bobos");
        pacienteService.cadastrar(paciente);
        Assertions.assertTrue(paciente.getId() > 0);
    }

}