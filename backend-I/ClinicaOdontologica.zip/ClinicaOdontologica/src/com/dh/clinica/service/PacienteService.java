package com.dh.clinica.service;

import com.dh.clinica.dao.impl.PacienteDaoH2;
import com.dh.clinica.model.Paciente;

import java.sql.SQLException;

public class PacienteService {

    private PacienteDaoH2 pacienteDao;

    public PacienteService(PacienteDaoH2 pacienteDao) {
        this.pacienteDao = pacienteDao;
    }

    public Paciente cadastrar(Paciente paciente) throws SQLException {
        return pacienteDao.cadastrar(paciente);
    }

}
