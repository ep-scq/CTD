package com.dh.computador.model;

public class Computador {
    private int ram;
    private int hd;

    private String id;

    public static int contador;

    public Computador(int ram, int hd, String id) {
        this.ram = ram;
        this.hd = hd;
        this.id = id;
        this.contador ++;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public int getHd() {
        return hd;
    }

    public void setHd(int hd) {
        this.hd = hd;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
