package com.dh.computador;

import com.dh.computador.factory.ComputadorFactory;
import com.dh.computador.model.Computador;

public class Main {
    public static void main(String[] args) {
        ComputadorFactory computador = new ComputadorFactory();
        Computador pc1 = computador.getComputador(16,500);
        Computador pc4 = computador.getComputador(16,500);
        Computador pc2 = computador.getComputador(2,256);
        Computador pc5 = computador.getComputador(2,256);
        Computador pc3 = computador.getComputador(16,600);

        System.out.println("Quantidade de Computadores criados: " + Computador.contador);

    }
}
