package com.dh.computador.factory;

import com.dh.computador.model.Computador;

import java.util.HashMap;
import java.util.Map;

public class ComputadorFactory {
    private static Map<String, Computador> computadorFlyweight = new HashMap<>();


    public Computador getComputador(int ram, int hd){
        String id = "id: "+ram+":"+hd;

        System.out.println(id);

        if(!computadorFlyweight.containsKey(id)){
            computadorFlyweight.put(id, new Computador(ram, hd, id));
            System.out.println("PC Criado");
            return computadorFlyweight.get(id);
        }
        System.out.println("PC Obtido");

        return computadorFlyweight.get(id);
    }

}
