import com.dh.aula12.jdbc.ConnectionJDBC;
import org.apache.log4j.Logger;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

    private static final Logger logger = Logger.getLogger(Main.class);

    private static final String sqlCreateTable = "DROP TABLE IF EXISTS Figura; " +
            "CREATE TABLE Figura" +
            "(" +
            " id INT PRIMARY KEY, " +
            " tipo VARCHAR(50) NOT NULL, " +
            " cor VARCHAR(50) NOT NULL" +
            ")";

    private static final String sqlInsertValue = "INSERT INTO Figura (id, tipo, cor) VALUES(1,'Circulo', 'Azul');";
    private static final String sqlInsertValue2 = "INSERT INTO Figura (id, tipo, cor) VALUES(2,'Circulo', 'Vermelho');";
    private static final String sqlInsertValue3 = "INSERT INTO Figura (id, tipo, cor) VALUES(3,'Quadrado', 'Branco');";
    private static final String sqlInsertValue4 = "INSERT INTO Figura (id, tipo, cor) VALUES(4,'Quadrado', 'Caramelo');";
    private static final String sqlInsertValue5 = "INSERT INTO Figura (id, tipo, cor) VALUES(5,'Quadrado', 'Verde');";

    private static final String sqlQuery = "SELECT * FROM Figura WHERE cor = 'Vermelho';";


    public static void main(String[] args) throws SQLException {

        Connection connection = null;

        try {

            connection = ConnectionJDBC.getConnection();
            logger.info("Conexão aberta");

            Statement statement = connection.createStatement();
            statement.execute(sqlCreateTable);
            logger.info("Banco Figura criado");
            statement.execute(sqlInsertValue);
            logger.info("Tipo inserido");
            statement.execute(sqlInsertValue2);
            logger.info("Tipo inserido");
            statement.execute(sqlInsertValue3);
            logger.info("Tipo inserido");
            statement.execute(sqlInsertValue4);
            logger.info("Tipo inserido");
            statement.execute(sqlInsertValue5);
            logger.info("Tipo inserido");

            ResultSet resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) {
                System.out.println("id :" + resultSet.getInt(1)
                        + "; tipo: " + resultSet.getNString(2)
                        + "; cor: " + resultSet.getString(3));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection == null) {
                return;

            }
            connection.close();

        }
    }
}
