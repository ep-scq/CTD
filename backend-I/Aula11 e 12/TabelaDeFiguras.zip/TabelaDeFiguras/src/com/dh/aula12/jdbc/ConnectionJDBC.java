package com.dh.aula12.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionJDBC {
    public static Connection getConnection() throws Exception{
        Class.forName("org.h2.Driver");
        return DriverManager.getConnection("jdbc:h2:~/test2", "sa","");
    }
}
