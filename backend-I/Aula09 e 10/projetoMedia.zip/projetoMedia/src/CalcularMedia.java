import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class CalcularMedia {
    private static final Logger logger = Logger.getLogger(CalcularMedia.class);
    private List<Integer> listaInteiros = new ArrayList<>();

    public CalcularMedia(List<Integer> listaInteiros) {
        this.listaInteiros = listaInteiros;
        calcularMedia();
        tamanhoLista();
    }

    public double calcularMedia(){

        int soma = 0;
        double media = 0;

        for (Integer inteiro : listaInteiros){
            soma += inteiro;
        }
        media = soma / listaInteiros.size();
        logger.info("A média é "+media);
        return media;
    }

    public void tamanhoLista(){
        if (listaInteiros.size() >=5 && listaInteiros.size() <=10){
            logger.info("O comprimento da lista é maior que 5");
        }
        if (listaInteiros.size() > 10){
            logger.info("O comprimento da lista é maior que 10");
        }
        if (listaInteiros.size() == 0){
            logger.error("A lista é igual a zero");
        }
    }

}
