import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        CalcularMedia calcularMedia = new CalcularMedia(Arrays.asList(8,4,2,6,7,2));

        CalcularMedia calcularMedia2 = new CalcularMedia(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11));

        CalcularMedia calcularMedia3 = new CalcularMedia(Arrays.asList());




    }
}
