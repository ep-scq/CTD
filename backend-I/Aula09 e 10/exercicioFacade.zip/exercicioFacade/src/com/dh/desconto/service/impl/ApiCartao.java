package com.dh.desconto.service.impl;

import com.dh.desconto.model.Cartao;

public class ApiCartao {
    public int desconto(Cartao cartao){
        if(cartao.getBanco().equalsIgnoreCase("Star Bank")){
            return 20;
        }
        return 0;
    }
}
