package com.dh.desconto.service.impl;

public class ApiQuantidade {
    public static int desconto(int quantidade){
        if(quantidade > 12){
            return 15;
        }
        return 0;
    }
}
