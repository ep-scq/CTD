package com.dh.desconto.service.impl;

import com.dh.desconto.model.Produto;

public class ApiProduto {
    public int desconto(Produto produto){
        if(produto.getTipo().equalsIgnoreCase("Lata")){
            return 10;
        }
        return 0;
    }
}
