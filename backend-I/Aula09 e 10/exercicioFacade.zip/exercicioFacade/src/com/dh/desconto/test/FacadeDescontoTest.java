package com.dh.desconto.test;

import com.dh.desconto.model.Cartao;
import com.dh.desconto.model.Produto;
import com.dh.desconto.service.impl.FacadeDesconto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FacadeDescontoTest {

    private FacadeDesconto facade;

    private Cartao cartao;
    private Produto produto;
    @BeforeEach
    void doBefore(){
        facade = new FacadeDesconto();
        cartao = new Cartao("123456", "Star Bank");
        produto = new Produto("Feijão", "Lata");
    }

    @Test
    @DisplayName("Executando teste de validação do desconto do banco")
    void validarDescontoBancoTest(){
        produto.setTipo("pacote");
        int desconto = facade.desconto(cartao, produto, 5);
        assertEquals(20, desconto);
    }

    @Test
    @DisplayName("Executando teste de validação do desconto do produto")
    void validarDescontoTest(){
        cartao.setBanco("Master");
        int desconto = facade.desconto(cartao, produto, 10);
        assertEquals(10, desconto);
    }

}