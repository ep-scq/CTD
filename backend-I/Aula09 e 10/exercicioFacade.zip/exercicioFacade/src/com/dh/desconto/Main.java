package com.dh.desconto;

import com.dh.desconto.model.Cartao;
import com.dh.desconto.model.Produto;
import com.dh.desconto.service.impl.FacadeDesconto;

public class Main {
    public static void main(String[] args) {
        FacadeDesconto facade = new FacadeDesconto();
        Cartao cartao = new Cartao("123456", "Star Bank");
        Produto produto = new Produto("Refrigerante", "Lata");

        int desconto = facade.desconto(cartao, produto, 12);

        System.out.println("Desconto: "+desconto+"%");
    }
}
