package com.dh.desconto.service;

import com.dh.desconto.model.Cartao;
import com.dh.desconto.model.Produto;

public interface IFacadeDesconto {
    public int desconto(Cartao cartao, Produto produto, int quantidade);
}
