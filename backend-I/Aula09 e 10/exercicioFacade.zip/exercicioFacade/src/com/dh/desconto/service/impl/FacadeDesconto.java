package com.dh.desconto.service.impl;

import com.dh.desconto.model.Cartao;
import com.dh.desconto.model.Produto;
import com.dh.desconto.service.IFacadeDesconto;

public class FacadeDesconto implements IFacadeDesconto {

    private ApiCartao apiCartao;
    private ApiProduto apiProduto;

    public FacadeDesconto(){
        apiCartao = new ApiCartao();
        apiProduto = new ApiProduto();
    }

    @Override
    public int desconto(Cartao cartao, Produto produto, int quantidade) {
        int desconto = 0;
        desconto += apiCartao.desconto(cartao);
        desconto += apiProduto.desconto(produto);
        desconto += ApiQuantidade.desconto(quantidade);
        return desconto;

        // O retorno abaixo pode substituir o retorno acima.
        // return apiCartao.desconto(cartao) + apiProduto.desconto(produto) + ApiQuantidade.desconto(quantidade);
    }
}
