package com.dh.hoteis.service;


import com.dh.hoteis.dao.Impl.HotelDaoH2;
import com.dh.hoteis.model.Hotel;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;

public class HotelServiceTest {

    HotelService service = new HotelService(new HotelDaoH2());
    Hotel hotel1 = new Hotel("Ibis", "rua Pacovan", "321", "Belem", "PA", 1);
    Hotel hotel2 = new Hotel("Ibis Top", "rua da Vila", "123", "Blalau", "GI", 0);
    Hotel hotel3 = new Hotel("Ibis F1", "rua Sem numero", "342", "Pepe", "TL", 1);
    Hotel hotel4 = new Hotel("Ibis Special", "rua do Amor", "444", "Birigui", "BE", 0);
    Hotel hotel5 = new Hotel("Ibis 2", "linha 100", "856", "Flores da Cunha", "RS", 1);

    @Test
    public void deveRetornarTrueQuandoCadastrarHotel() throws SQLException {
        service.cadastrar(hotel1);
        service.cadastrar(hotel2);
        service.cadastrar(hotel3);
        service.cadastrar(hotel4);
        service.cadastrar(hotel5);


        Assertions.assertTrue(hotel1.getId() > 0);
        Assertions.assertTrue(hotel2.getId() > 0);
        Assertions.assertTrue(hotel3.getId() > 0);
        Assertions.assertTrue(hotel4.getId() > 0);
        Assertions.assertTrue(hotel5.getId() > 0);
    }
}