package com.dh.hoteis.dao.Impl;

import com.dh.hoteis.dao.ConfiguracaoJDBC;
import com.dh.hoteis.dao.IDao;
import com.dh.hoteis.model.Hotel;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class HotelDaoH2 implements IDao <Hotel> {

    private static ConfiguracaoJDBC configuracaoJDBC = new ConfiguracaoJDBC("org.h2.Driver","jdbc:h2:~/elihotel;INIT=RUNSCRIPT FROM 'create.sql'","sa","");
    final static Logger logger = Logger.getLogger(HotelDaoH2.class);

    @Override
    public Hotel cadastrar(Hotel hotel) throws SQLException {

        Connection connection = configuracaoJDBC.getConnection();
        String query = String.format("INSERT INTO Hoteis (nomeFilial, rua, numero, cidade, estado, cincoEstrelas)" +
                " VALUES ('%s','%s','%s','%s','%s','%s');",hotel.getNomeFilial(), hotel.getRua(), hotel.getNumero(), hotel.getCidade(), hotel.getEstado(), hotel.getCincoEstrelas());
        logger.info("Cadastrando Hotel "+hotel.getNomeFilial());


        try {
            logger.info("Hotel cadastrado com sucesso!");
            Statement statement = connection.createStatement();
            statement.execute(query,Statement.RETURN_GENERATED_KEYS);

            ResultSet resultSet = statement.getGeneratedKeys();

            if(resultSet.next()){
                hotel.setId(resultSet.getInt(1));
            }

        }catch (Exception e){
            e.printStackTrace();
            logger.error("Ocorreu um erro no cadastro.");

        }finally {
            connection.close();
        }


        return hotel;
    }

    @Override
    public void excluir(int id) {

    }
}