package com.dh.hoteis.service;

import com.dh.hoteis.dao.Impl.HotelDaoH2;
import com.dh.hoteis.model.Hotel;

import java.sql.SQLException;

public class HotelService {
    private HotelDaoH2 hotelDao;

    public HotelService(HotelDaoH2 hotelDao) {
        this.hotelDao = hotelDao;
    }

    public Hotel cadastrar(Hotel hotel) throws SQLException {
        return hotelDao.cadastrar(hotel);
    }

}
