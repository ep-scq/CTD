import com.dh.hoteis.dao.Impl.HotelDaoH2;
import com.dh.hoteis.model.Hotel;
import com.dh.hoteis.service.HotelService;

import java.sql.SQLException;


    public class Main {
        public static void main(String[] args) throws SQLException {
            Hotel hotel1 = new Hotel("Ibis", "rua Pacovan", "321", "Belem", "PA", 1);
            HotelDaoH2 dao = new HotelDaoH2();
            HotelService service = new HotelService(dao);

            service.cadastrar(hotel1);
        }
    }