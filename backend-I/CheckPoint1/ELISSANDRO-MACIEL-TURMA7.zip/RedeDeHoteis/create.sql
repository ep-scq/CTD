create table if not exists Hoteis (
 id int auto_increment primary key,
 nomeFilial varchar(100),
 rua varchar(100),
 numero varchar(20),
 cidade varchar(100),
 estado varchar(100),
 cincoEstrelas tinyint)