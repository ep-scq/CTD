package com.digitalhouse.junit.exercicio;

public interface Figura {

    public double calcularPerimetro();

}
