package com.example.PrimeiroProjetoSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroProjetoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
