public interface Observador {
    public String atualizar();
}
