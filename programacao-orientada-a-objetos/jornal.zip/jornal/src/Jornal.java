import java.time.LocalDate;

public class Jornal {
    private String autor;
    private LocalDate data;

    private Revista revista;

    public Jornal(String autor, LocalDate data) {
        this.autor = autor;
        this.data = data;
    }

    public Jornal(String autor, LocalDate data, Revista revista) {
        this.autor = autor;
        this.data = data;
        this.revista = revista;
    }

    public String getAutor() {
        return autor;
    }

    public LocalDate getData() {
        return data;
    }

    public Revista getRevista(){
        return revista;
    }

    public void setRevista(Revista revista) {
        this.revista = revista;
    }

}
