import java.time.LocalDate;

public class Revista {
    private String nome;
    private LocalDate data;
    private String periodicidade;

    private Edicao edicao;

    public Revista(String nome, LocalDate data, String periodicidade) {
        this.nome = nome;
        this.data = data;
        this.periodicidade = periodicidade;
    }

    public Revista(String nome, LocalDate data, String periodicidade, Edicao edicao) {
        this.nome = nome;
        this.data = data;
        this.periodicidade = periodicidade;
        this.edicao = edicao;
    }

    public String getNome() {
        return nome;
    }

    public LocalDate getData() {
        return data;
    }

    public String getPeriodicidade() {
        return periodicidade;
    }

    public Edicao getEdicao() {
        return edicao;
    }

    public void setEdicao(Edicao edicao) {
        this.edicao = edicao;
    }
}
