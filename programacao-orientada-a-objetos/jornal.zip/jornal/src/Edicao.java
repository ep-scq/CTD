import java.time.LocalDate;
import java.util.List;

public class Edicao {
    private Integer numeroEdicao;
    private LocalDate data;

    private Double preco;
    private List<Artigo> artigo;

    public Edicao(Integer numeroEdicao, LocalDate data, Double preco) {
        this.numeroEdicao = numeroEdicao;
        this.data = data;
        this.preco = preco;
    }

    public Edicao(Integer numeroEdicao, LocalDate data, Double preco, Artigo artigo) {
        this.numeroEdicao = numeroEdicao;
        this.data = data;
        this.preco = preco;
        this.artigo = List.of(artigo);
    }

    public Integer getNumeroEdicao() {
        return numeroEdicao;
    }

    public LocalDate getData() {
        return data;
    }

    public Double getPreco() {
        return preco;
    }

    public Artigo getArtigo() {
        return artigo;
    }

    public void setArtigo(Artigo artigo) {
        this.artigo = artigo;
    }
}
