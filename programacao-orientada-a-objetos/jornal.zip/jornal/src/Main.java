import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        System.out.println("Inicio do projeto:");

        Artigo artigo = new Artigo("Melhores séries de TV", "Melhores séries de TV - dos anos 2000", "Rodrigo", "Do mesmo modo, o julgamento imparcial das eventualidades representa uma abertura para a melhoria dos modos de operação convencionais.", LocalDate.of(2021, 7, 20));
        Edicao edicao = new Edicao(15, LocalDate.of(2021, 7, 20), 29.99, artigo);
        Revista revista = new Revista("Todo mundo odeia o crís", LocalDate.of(2022, 7, 20), "Semanal", edicao);
        Jornal jornal = new Jornal("Julius", LocalDate.now(), revista);
        Jornal jornal2 = new Jornal("Juasd", LocalDate.now(), revista);
        Jornal jornal3 = new Jornal("Juasd", LocalDate.now(), revista);
        Jornal jornal4 = new Jornal("asdasd", LocalDate.now(), revista);

        System.out.println();


    }
}