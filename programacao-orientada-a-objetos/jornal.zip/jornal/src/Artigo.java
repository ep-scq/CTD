import java.time.LocalDate;

public class Artigo {
    private String titulo;
    private String assunto;
    private String autor;
    private String descricao;
    private LocalDate data;

    public Artigo(String titulo, String assunto, String autor, String descricao, LocalDate data) {
        this.titulo = titulo;
        this.assunto = assunto;
        this.autor = autor;
        this.descricao = descricao;
        this.data = data;
    }



    public String getTitulo() {
        return titulo;
    }

    public String getAssunto() {
        return assunto;
    }

    public String getAutor() {
        return autor;
    }

    public String getDescricao() {
        return descricao;
    }

    public LocalDate getData() {
        return data;
    }
}
