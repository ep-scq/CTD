public class Objeto {
    private Integer posx;
    private Integer posy;
    private Character direcao;

    public Objeto(Integer posx, Integer posy, char direcao) {
        this.posx = posx;
        this.posy = posy;
        this.direcao = direcao;
    }

    public Integer getPosx() {
        return posx;
    }

    public void setPosx(Integer posx) {
        this.posx = posx;
    }

    public Integer getPosy() {
        return posy;
    }

    public void setPosy(Integer posy) {
        this.posy = posy;
    }

    public Character getDirecao() {
        return direcao;
    }

    public void setDirecao(Character direcao) {
        this.direcao = direcao;
    }

    public void irA(int x, int y, char direcao){
        this.posx = x;
        this.posy = y;
        this.direcao = direcao;

    }

}


