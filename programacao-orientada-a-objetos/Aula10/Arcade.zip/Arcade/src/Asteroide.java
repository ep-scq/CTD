public class Asteroide extends Objeto{
    private Integer Danos;

    public Asteroide(Integer posx, Integer posy, Character direcao, Integer danos) {
        super(posx, posy, direcao);
        Danos = danos;
    }

    @Override
    public void irA(int x, int y, char direcao) {
        super.irA(x, y, direcao);
    }
}
