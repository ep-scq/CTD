public class Nave extends Objeto{
    private Double velocidade;
    private Integer vida;

    public Nave(Integer posx, Integer posy, char direcao, Double velocidade, Integer vida) {
        super(posx, posy, direcao);
        this.velocidade = velocidade;
        this.vida = vida;
    }

    public Double getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(Double velocidade) {
        this.velocidade = velocidade;
    }

    public Integer getVida() {
        return vida;
    }

    public void setVida(Integer vida) {
        this.vida = vida;
    }

    @Override
    public void irA(int x, int y, char direcao) {
        super.irA(x, y, direcao);
    }
    public void girar(char direcao){
        irA(getPosx(), getPosy(), direcao);
    }

}


