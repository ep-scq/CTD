public class PacienteException extends RuntimeException {

    public PacienteException(String message) {
        super(message);

    }
}