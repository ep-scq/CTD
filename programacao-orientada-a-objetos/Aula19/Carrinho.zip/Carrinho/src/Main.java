public class Main {
    public static void main(String[] args) {
        //Alunos: Gui / Elissandro / Victor / Allan / Ana Carolina / Veronica

        System.out.println("Hello world!");
    }
}