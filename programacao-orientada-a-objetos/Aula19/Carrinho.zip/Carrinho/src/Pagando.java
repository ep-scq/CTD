public class Pagando implements Estado{


    Carrinho carrinho;

    public Pagando(Carrinho carrinho) {
        this.carrinho = carrinho;
        System.out.println("Pagando carrinho");
    }

    @Override
    public void adicionar() {
        System.out.println("Seu carrino já está em processo de pgto");
    }

    @Override
    public void cancelar() {
        this.carrinho.setEstado(new Vazio(carrinho));
    }

    @Override
    public void retornar() {
        this.carrinho.setEstado(new Carregando(carrinho));
    }

    @Override
    public void proximoEstado() {
        this.carrinho.setEstado(new Fechado(carrinho));

    }
}
