public class Fechado implements Estado{

    Carrinho carrinho;

    public Fechado(Carrinho carrinho) {
        this.carrinho = carrinho;
        System.out.println("Carrinho fechado");
    }

    @Override
    public void adicionar() {
        System.out.println("Carrinho já fechado");
    }

    @Override
    public void cancelar() {
        this.carrinho.setEstado(new Vazio(carrinho));
    }

    @Override
    public void retornar() {
        System.out.println("Impossível retornar, carrinho fechado.");
    }

    @Override
    public void proximoEstado() {
        this.carrinho.setEstado(new Vazio(carrinho));

    }
}
