import java.util.ArrayList;

public class Vazio implements Estado{

    Carrinho carrinho;

    public Vazio(Carrinho carrinho) {
        this.carrinho = carrinho;
        System.out.println("Carrinho está vazio");
    }

    @Override
    public void adicionar() {

    }

    @Override
    public void cancelar() {
        System.out.println("Seu carrinho já está vazio");
    }

    @Override
    public void retornar() {
        System.out.println("Seu carrinho já está vazio");
    }

    @Override
    public void proximoEstado() {
        this.carrinho.setEstado(new Carregando(carrinho));

    }
}
