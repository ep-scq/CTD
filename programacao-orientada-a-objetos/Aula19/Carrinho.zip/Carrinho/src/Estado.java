public interface Estado {

    void adicionar();
    void cancelar();
    void retornar();
    void proximoEstado();
}
