public class Carregando implements Estado{


    Carrinho carrinho;

    public Carregando(Carrinho carrinho) {
        this.carrinho = carrinho;
        System.out.println("Carrinho carregando");
    }

    @Override
    public void adicionar() {

    }

    @Override
    public void cancelar() {
        this.carrinho.setEstado(new Vazio(carrinho));
    }

    @Override
    public void retornar() {
        this.carrinho.setEstado(new Vazio(carrinho));
    }

    @Override
    public void proximoEstado() {
        this.carrinho.setEstado(new Pagando(carrinho));

    }
}
