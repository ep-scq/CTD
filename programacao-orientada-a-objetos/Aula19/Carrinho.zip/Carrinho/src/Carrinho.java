import java.util.ArrayList;



public class Carrinho {
    private Estado estado;

    private ArrayList<Produto> listaProduto = new ArrayList<>();



    public ArrayList<Produto> getListaProduto() {
        return listaProduto;
    }

    public void setListaProduto(ArrayList<Produto> listaProduto) {
        this.listaProduto = listaProduto;
    }

    public Carrinho() {
        this.setEstado(new Vazio(this));
    }

    public void adicionar(){
        this.getEstado().adicionar();
    }
    public void cancelar(){
        this.getEstado().cancelar();
    }
    public void retornar(){
        this.getEstado().retornar();
    }
    public void proximoEstado(){
        this.getEstado().proximoEstado();
    }

    public Estado getEstado(){
        return this.estado;
    }


    public void setEstado(Estado estado) {
        this.estado = estado;
    }

}
